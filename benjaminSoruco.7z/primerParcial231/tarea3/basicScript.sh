#!/bin/bash

# 1. Pedir el nombre al usuario
read -p "Ingrese su nombre: " nombre

# 2. Mostrar un saludo personalizado
echo "Hola, $nombre. Estas dentro del script de Tarea 3"

# 3. Guardar la ubicación actual
mkdir -p Tarea3/ubicaciones
pwd > Tarea3/ubicaciones/ubicacion.txt

# 4. Guardar la fecha de ejecución
date > Tarea3/fechaTarea3.txt

# 5. Listar el contenido de la carpeta Tarea3
echo -e "Contenido de la carpeta Tarea3:"
ls -l Tarea3

# 6. Mensaje final
echo -e "El script se ha ejecutado correctamente."

